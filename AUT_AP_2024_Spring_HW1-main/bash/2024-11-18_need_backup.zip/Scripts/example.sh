#!/bin/bash
echo 'This is a script file named example'
